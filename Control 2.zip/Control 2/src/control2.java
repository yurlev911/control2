import java.util.Scanner;

public class control2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите число, не меньшее 2: ");
        int number = scanner.nextInt();

        if (number < 2) {
            System.out.println("Число должно быть не меньше 2.");
        } else {
            int smallestDivisor = findSmallestDivisor(number);
            System.out.println("Наименьший натуральный делитель, отличный от 1: " + smallestDivisor);
        }
    }

    public static int findSmallestDivisor(int number) {
        for (int i = 2; i <= Math.sqrt(number); i++) {
            if (number % i == 0) {
                return i;
            }
        }
        return number; // Если не нашлось меньшего делителя, значит число само является простым
    }
}
