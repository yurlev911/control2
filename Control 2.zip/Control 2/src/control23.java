import java.util.Scanner;

public class control23 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Ввод координат вершин треугольника
        System.out.print("Введите x1: ");
        double x1 = scanner.nextDouble();
        System.out.print("Введите y1: ");
        double y1 = scanner.nextDouble();
        System.out.print("Введите x2: ");
        double x2 = scanner.nextDouble();
        System.out.print("Введите y2: ");
        double y2 = scanner.nextDouble();
        System.out.print("Введите x3: ");
        double x3 = scanner.nextDouble();
        System.out.print("Введите y3: ");
        double y3 = scanner.nextDouble();

        // Вычисление длины сторон треугольника
        double sideA = distance(x1, y1, x2, y2);
        double sideB = distance(x2, y2, x3, y3);
        double sideC = distance(x3, y3, x1, y1);

        // Вычисление периметра
        double perimeter = sideA + sideB + sideC;

        // Вывод результата
        System.out.printf("Периметр треугольника равен %.2f%n", perimeter);
    }

    // Метод для вычисления длины отрезка по координатам его концов
    public static double distance(double x1, double y1, double x2, double y2) {
        return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    }
}
