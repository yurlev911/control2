import java.util.Scanner;

public class control24 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите число: ");
        int number = scanner.nextInt();

        // Проверка на отрицательное число
        if (number < 0) {
            System.out.println("Факториал не определен для отрицательных чисел.");
        } else {
            long result = factorial(number);
            System.out.println("Факториал " + number + " равен " + result);
        }
    }

    // Рекурсивный метод для вычисления факториала
    public static long factorial(int n) {
        if (n == 0) {
            return 1; // Базовый случай: факториал 0 равен 1
        } else {
            return n * factorial(n - 1); // Рекурсивный случай
        }
    }
}
